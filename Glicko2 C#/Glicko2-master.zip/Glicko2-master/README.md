# Glicko2
A C# imlementation of the Glicko ranking formula.

Wiki: https://github.com/ikhanage/Glicko2/wiki
Report Issues Here: https://github.com/ikhanage/Glicko2/issues
